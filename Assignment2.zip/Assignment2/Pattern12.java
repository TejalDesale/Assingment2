import java.util.*;

class Pattern12
{
 public static void main(String args[])
  {
	  int num;
	  Scanner sc=new Scanner(System.in);
	  System.out.println("Enter value");
	  num=sc.nextInt();
	  int k=num;
	  for(int i=1; i<=k; i++)
	  {
              for(int x=1; x<=i;x++)
              {
                  System.out.print(" ");
              }
              
		  for(int j=num; j>=i; j--)
		  {
			  System.out.print("* ");
		  }
		  
		   System.out.println("\n");
		   
	  }
	  
  }
}